import matplotlib.pyplot as plt
import pmdarima as pm
import pandas as pd
import datetime
from tools import *
from statsmodels.tsa.statespace.sarimax import SARIMAX

def forecastTitle(name,type):
    fixed = [('Total','Whole House'),('Kitchen','Kitchen'),('Laundry','Laundry Room'),('Heating','Heating'),('Other',"Rest of the House")]
    for fix in zip(fixed):
        if name == fix[0][0]:
            return type+' for the {}'.format(fix[0][1])


def forecastParams(dic):
    if dic['Location'].getActive() == 'All':
        DV = 'Total_'+dic['Display'].state()
    else:
        DV = dic['Location'].getActive()+'_'+dic['Display'].state()

    period = dic['Period'].getActive()
    return (DV, period)

def plotForecast(datasets,DV,period):
    if period == '1 Year':
        df = datasets['1 Month']
        SARIMA= pm.auto_arima(df[DV], start_p=1, start_q=1,
                             test='adf',max_p=2, max_q=2,seasonal=True,m=12,D=2)
        forecast, confint = SARIMA.predict(n_periods=12, return_conf_int=True)
        forecastIndex = pd.date_range(df.index[-1] + pd.DateOffset(months=1), periods = 12, freq='M')

    elif period == "1 Day":
        df = datasets['1 Hour']
        dateRangeForecast = pd.date_range(df.index[-1] - pd.DateOffset(hours=24*7*4), df.index[-1], freq='H')
        model = SARIMAX(endog=df.loc[dateRangeForecast,DV],seasonal_order=(1,1,0,24),freq='H')
        fit = model.fit()
        forecast = fit.get_forecast(24).predicted_mean
        confint = fit.get_forecast(24).conf_int(alpha=0.2)
        dateRangePlot = pd.date_range(df.index[-1] - pd.DateOffset(hours=24 * 5), df.index[-1], freq='H')

    elif period == '1 Month':
        df = datasets['1 Day']
        model = SARIMAX(endog=df[DV],order=(1,0,0),seasonal_order=(1,1,0,30),freq='D')
        fit = model.fit()
        forecast = fit.get_forecast(30).predicted_mean
        confint = fit.get_forecast(30).conf_int(alpha=0.2)
        dateRangePlot = pd.date_range(df.index[-1] - pd.DateOffset(days=30*5), df.index[-1], freq='D')

    else:
        df = datasets['1 Day']
        model = SARIMAX(endog=df[DV],order=(1,0,0),seasonal_order=(1,1,0,30),freq='D')
        fit = model.fit()
        forecast = fit.get_forecast(7).predicted_mean
        confint = fit.get_forecast(7).conf_int(alpha=0.2)
        dateRangePlot = pd.date_range(df.index[-1] - pd.DateOffset(days=28), df.index[-1], freq='D')


    plt.figure(figsize=(10,6),dpi=95)
    if period == '1 Year':
        plt.plot(df[DV], c='#82c268')
        plt.plot(pd.Series(forecast, index=forecastIndex), '--',c='#1b7709')
        plt.fill_between(forecastIndex,
                        pd.Series(confint[:, 0], index=forecastIndex),
                        pd.Series(confint[:, 1], index=forecastIndex)
                     , alpha=.15)
    else:
        plt.plot(dateRangePlot, df.loc[dateRangePlot, DV], c='#82c268')
        plt.plot(forecast.index, forecast, '--', c='#1b7709')
        plt.fill_between(confint.index,
                         confint.iloc[:, 0],
                         confint.iloc[:, 1]
                         , alpha=.15)

    name = DV.split('_')[0]
    type = DV.split('_')[1]

    if type == 'Consumption':
        unit = "kWh"
        if period == '1 Day':
            plt.ylabel('Energy consumed per Hour (kWh)')
        elif period in ['1 Week','1 Month']:
            plt.ylabel('Energy consumed per Day (kWh)')
        else:
            plt.ylabel('Energy consumed per Month (kWh)')
    else:
        unit = "€"
        if period == '1 Day':
            plt.ylabel('Cost per Hour (€)')
        elif period in ['1 Week','1 Month']:
            plt.ylabel('Cost per Day (€)')
        else:
            plt.ylabel('Cost per Month (€)')

    plt.xlabel('Date')
    plt.legend(['Past',"Forecast"])

    total = round(forecast.sum(),2)

    if period == '1 Day':
        plt.title("Tomorrow's forecast of the Energy {}".format(forecastTitle(name,type)))
        text = "Forecasted Total Energy {} Tomorrow: {} {}".format(forecastTitle(name,type),total,unit)
    elif period == '1 Week':
        plt.title("Next Week's forecast of the Energy {}".format(forecastTitle(name, type)))
        text = "Forecasted Total Energy {} Next Week: {} {}".format(forecastTitle(name,type), total, unit)
    elif period == '1 Month':
        plt.title("Next Month's forecast of the Energy {}".format(forecastTitle(name, type)))
        text = "Forecasted Total Energy {} Next Month: {} {}".format(forecastTitle(name,type), total, unit)
    else:
        plt.title("Next Year's forecast of the Energy {}".format(forecastTitle(name, type)))
        text = "Forecasted Total Energy {} Next Year: {} {}".format(forecastTitle(name,type), total, unit)

    plt.gcf().autofmt_xdate()
    plt.ylim(-0.001)
    plt.savefig('forecasting.png')
    return(text)


def ts_bar_Params(dic):
    locations = [object.getLabel() for object in dic['Location'] if object.active]
    title = dic["Title"].getText()
    period = dic['Period'].getActive()
    start_date = datetime.datetime.strptime(dic['Date'][0].getText(), '%d/%m/%Y')
    end_date = datetime.datetime.strptime(dic['Date'][1].getText(), '%d/%m/%Y')
    if start_date > end_date:
        debugWin = GraphWin('Error',300,200)
        debugWin.setBackground('#cbf3ae')
        message = Text(Point(150,50),"Start date after final date!")
        message.setStyle("bold")
        message.setFace('courier')
        message.setFill("#1b7709")
        message.draw(debugWin)
        skip = ActionButton(debugWin,Point(100,125),Point(200,85),"Continue",debugWin.close)
        checkClicks(debugWin,[skip],None,None)
        return
    display = dic['Display'].state()
    return(display,locations,start_date,end_date,period,title)


def tsPlot(datasets, display, locations, start_date, end_date, period,title):
    df = datasets[period]
    if period == '1 Hour':
        daterange = pd.date_range(start_date, end_date, freq="H")
    elif period == '1 Day':
        daterange = pd.date_range(start_date, end_date)
    else:
        daterange = pd.date_range(start_date, end_date, freq='M')

    plt.figure(figsize=(10, 6), dpi=95)
    if 'Kitchen' in locations:
        plt.plot(df.loc[daterange, :].index, df.loc[daterange, 'Kitchen_{}'.format(display)],color="#ff7f0e")
    if 'Heating' in locations:
        plt.plot(df.loc[daterange, :].index, df.loc[daterange, 'Heating_{}'.format(display)],color="#d62728")
    if 'Laundry' in locations:
        plt.plot(df.loc[daterange, :].index, df.loc[daterange, 'Laundry_{}'.format(display)],color="#2ca02c")
    if 'Other' in locations:
        plt.plot(df.loc[daterange, :].index, df.loc[daterange, 'Other_{}'.format(display)],color="#9467bd")
    if 'All' in locations:
        plt.plot(df.loc[daterange, :].index, df.loc[daterange, 'Total_{}'.format(display)], color="#1f77b4")

    if display == 'Consumption':
        if period == '1 Hour':
            plt.ylabel('Energy consumed per Hour (kWh)')
        elif period == '1 Day':
            plt.ylabel('Energy consumed per Day (kWh)')
        else:
            plt.ylabel('Energy consumed per Month (kWh)')
    else:
        if period == '1 Hour':
            plt.ylabel('Cost per Hour (€)')
        elif period == '1 Day':
            plt.ylabel('Cost per Day (€)')
        else:
            plt.ylabel('Cost per Month (€)')


    plt.title(title)
    plt.xlabel('Date')
    plt.legend(locations, loc=1)
    plt.gcf().autofmt_xdate()
    plt.ylim(-0.001)
    plt.savefig('timeseries.png')



def order_weekday_months(period,index):
    if period == 'Month':
        months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
        for i, month in enumerate(months):
            if month in index:
                start = i
                break
        for i, month in enumerate(months[-1::-1]):
            if month in index:
                end = 12-i
                break

        return months[start:end]

    elif period == 'Weekday':
        weekdays = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
        for i, day in enumerate(weekdays):
            if day in index:
                start = i
                break
        for i, day in enumerate(weekdays[-1::-1]):
            if day in index:
                end = 7 - i
                break

        return weekdays[start:end]



def barPlot(datasets, display, locations, start_date, end_date, period,title):
    if period == 'Hour of Day':
        df = datasets['1 Hour']
        dateRange = pd.date_range(start_date,end_date, freq='H')
        df = df.loc[dateRange,:].groupby('Hour').mean()
    elif period == 'Weekday':
        df = datasets['1 Day']
        dateRange = pd.date_range(start_date,end_date)
        df = df.loc[dateRange,:].groupby('Weekday').mean()
        if list(df.index):
            df = df.loc[order_weekday_months(period,df.index),:]
    elif period == 'Month':
        df = datasets['1 Month']
        dateRange = pd.date_range(start_date,end_date, freq='M')
        df = df.loc[dateRange,:].groupby('Month').mean()
        if list(df.index):
            df = df.loc[order_weekday_months(period,df.index),:]

    plt.figure(figsize=(10, 6), dpi=95)
    bottom = 0
    if 'Kitchen' in locations:
        kitchen = df['Kitchen_{}'.format(display)]
        plt.bar(df.index, kitchen,label='Kitchen',color ="#ff7f0e")
        bottom = kitchen
    if 'Laundry' in locations:
        laundry = df['Laundry_{}'.format(display)]
        plt.bar(df.index, laundry,label='Laundry',bottom=bottom,color="#2ca02c")
        bottom += laundry
    if 'Heating' in locations:
        heating = df['Heating_{}'.format(display)]
        plt.bar(df.index, heating,label='Heating',bottom=bottom,color="#d62728")
        bottom += heating
    if 'Other' in locations:
            other = df['Other_{}'.format(display)]
            plt.bar(df.index, other,label='Other',bottom=bottom, color = "#9467bd")

    if display == 'Consumption':
        plt.ylabel('Mean Energy Consumption (Kwh)')
    else:
        plt.ylabel('Mean Energy Cost (€)')


    if period == 'Hour of Day':
        plt.xlabel("Hour of the Day")
        plt.xticks(range(24),range(24))
    elif period == 'Weekday':
        plt.xlabel("Weekday")
    else:
        plt.xlabel("Month of the Year")

    plt.title(title)
    plt.legend(locations, loc=1)
    plt.gcf().autofmt_xdate()
    plt.ylim(-0.001)
    plt.savefig('barplot.png')






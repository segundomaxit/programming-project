from plot_functions import *

byMonth = pd.read_csv('Energy by Month.csv').set_index('Datetime')
byMonth.index = pd.to_datetime(byMonth.index)
byDay = pd.read_csv('Energy by Day.csv').set_index('Day')
byDay.index = pd.to_datetime(byDay.index)
byHour = pd.read_csv('Energy by Hour.csv').set_index('Datetime')
byHour.index = pd.to_datetime(byHour.index)


datasets = {'1 Hour':byHour,
            '1 Day':byDay,
            '1 Month':byMonth}


def createPlot(win, menuButtons, menuWindows,menuDic):
    try:
        pageNames = ['Time Series','Bar','Forecasting']
        loading = Text(Point(100, 60), 'Loading...')
        loading.setSize(20)
        loading.setStyle("bold")
        loading.setFace('courier')
        loading.setFill("#1b7709")
        total = loading.clone()
        total.move(0,-55)
        total.setSize(12)
        for i, button in enumerate(menuButtons):
            pageName = pageNames[i]
            if button.active:
                if pageName == 'Time Series':
                    params = ts_bar_Params(menuDic[i])
                    tsPlot(datasets, *params)
                    loading.draw(win)
                    timeseriesPlotImage = Image(Point(100, 60), 'timeseries.png')
                    loading.undraw()
                    timeseriesPlotImage.draw(win)
                    if type(menuWindows[i][-1]) is Image:
                        menuWindows[i][-1].undraw()
                        menuWindows[i].pop()
                        menuWindows[i].append(timeseriesPlotImage)
                    else:
                        menuWindows[i].append(timeseriesPlotImage)
                elif pageName == 'Bar':
                    params = ts_bar_Params(menuDic[i])
                    barPlot(datasets, *params)
                    loading.draw(win)
                    barPlotImage = Image(Point(100, 60), 'barplot.png')
                    loading.undraw()
                    barPlotImage.draw(win)
                    if type(menuWindows[i][-1]) is Image:
                        menuWindows[i][-1].undraw()
                        menuWindows[i].pop()
                        menuWindows[i].append(barPlotImage)
                    else:
                        menuWindows[i].append(barPlotImage)
                else:
                    params = forecastParams(menuDic[i])
                    loading.draw(win)
                    total.setText(plotForecast(datasets,*params))
                    forecastPlot = Image(Point(100,60),'forecasting.png')
                    loading.undraw()
                    forecastPlot.draw(win)
                    total.draw(win)
                    if type(menuWindows[i][-2]) is Image:
                        menuWindows[i][-1].undraw()
                        menuWindows[i][-2].undraw()
                        menuWindows[i].pop()
                        menuWindows[i].pop()
                        menuWindows[i].extend([forecastPlot,total])
                    else:
                        menuWindows[i].extend([forecastPlot,total])

    except KeyError:
        debugWin = GraphWin('Error',300,200)
        debugWin.setBackground('#cbf3ae')
        message = Text(Point(150,50),"Oustide available date range!")
        message.setStyle("bold")
        message.setFace('courier')
        message.setFill("#1b7709")
        Range = message.clone()
        Range.move(0,100)
        Range.setText("Available date range:")
        dateRange = message.clone()
        dateRange.move(0,125)
        dateRange.setText("{} - {}".format(byDay.index[0].strftime("%d/%m/%Y"),byDay.index[-1].strftime("%d/%m/%Y")))
        message.draw(debugWin)
        Range.draw(debugWin)
        dateRange.draw(debugWin)
        skip = ActionButton(debugWin,Point(100,125),Point(200,85),"Continue",debugWin.close)
        checkClicks(debugWin,[skip],None,None)
    except ValueError:
        debugWin = GraphWin("Error",300,200)
        debugWin.setBackground('#cbf3ae')
        message = Text(Point(150,50),"Invalid Date Format!")
        message.setStyle("bold")
        message.setFace('courier')
        message.setFill("#1b7709")
        message.draw(debugWin)
        skip = ActionButton(debugWin,Point(100,125),Point(200,85),"Continue",debugWin.close)
        checkClicks(debugWin, [skip], None, None)

    except TypeError:
        return



def Dic2List(dic):
    List = []
    for item in dic.values():
        if type(item) is list:
            for values in item:
                List.append(values)
        else:
            List.append(item)

    return List














from graphics import *


def checkClicks(win, buttons,menu, switches):
    while True:
        try:
            click = win.getMouse()
            x = click.getX()
            y = click.getY()

            for button in buttons:
                x1 = button.rectangle.getP1().x
                y1 = button.rectangle.getP1().y
                x2 = button.rectangle.getP2().x
                y2 = button.rectangle.getP2().y

                if (x > x1 and x < x2) and (y < y1 and y > y2):
                    if button.type == 'state':
                        button.changeState()
                    elif button.type == 'action':
                        button.action()
                    elif button.type == 'switchMultiple':
                        for switch in switches:
                            if button in switch.buttons:
                                switch.changeState(button)
                    elif button.type == 'menu':
                        menu.changeWindow(button)
        except GraphicsError:
            return





class OptionButton:
    def __init__(self, win, p1, p2, label, widthOn=2, widthOff=1, fill='#9cd37c',outline='#1b7709',fillOn='#1b7709', fillOff='darkgray', type="state",bold=False,size=12):
        self.win = win
        self.fillOn = fillOn
        self.fillOff = fillOff
        self.rectangle = Rectangle(p1, p2)
        self.rectangle.setFill(fill)
        self.rectangle.setOutline(outline)
        self.label = Text(self.rectangle.getCenter(), label)
        self.label.setSize(size)
        self.label.setFace('courier')
        self.widthOn = widthOn
        self.widthOff = widthOff
        self.bold = bold
        self.active = True
        self.type = type
        self.changeState()
        self.drawn = False

    def state(self):
        return self.active

    def getLabel(self):
        return self.label.getText()

    def changeState(self):
        if not self.active:
            self.label.setTextColor(self.fillOn)
            self.rectangle.setWidth(self.widthOn)
            if self.bold:
                self.label.setStyle('bold')
            self.active = True
        else:
            self.label.setTextColor(self.fillOff)
            self.rectangle.setWidth(self.widthOff)
            if self.bold:
                self.label.setStyle('normal')
            self.active = False

    def undraw(self):
        self.rectangle.undraw()
        self.label.undraw()

    def draw(self):
        self.rectangle.draw(self.win)
        self.label.draw(self.win)
        return self




class Switch:
    def __init__(self, b1, b2):
        self.rectangle = Rectangle(b1.rectangle.p1, b2.rectangle.p2)
        self.On = b1
        self.Off = b2
        self.On.active = False
        self.Off.active = True
        self.On.changeState()
        self.Off.changeState()
        self.type = "state"
        self.drawn = False

    def changeState(self):
        self.On.changeState()
        self.Off.changeState()

    def state(self):
        if self.On.active:
            return self.On.getLabel()
        else:
            return self.Off.getLabel()

    def undraw(self):
        self.On.undraw()
        self.Off.undraw()

    def draw(self):
        self.On.draw()
        self.Off.draw()

class SwitchMultiple:
    def __init__(self, buttons):
        self.buttons = buttons
        self.buttons[0].changeState()
        self.active = self.buttons[0]
        self.type = "switchMultiple"
        self.drawn = False

    def changeState(self,clickedButton):
        for button in self.buttons:
            if (button == clickedButton) and (button != self.active):
                button.changeState()
                self.active.changeState()
                self.active = button

    def getActive(self):
        return self.active.getLabel()


    def undraw(self):
        for button in self.buttons:
            button.undraw()

    def draw(self):
        for button in self.buttons:
            button.draw()


class ActionButton():
    def __init__(self, win, p1, p2, label, fun, args=None):
        self.win = win
        self.p1 = p1
        self.p2 = p2
        self.rectangle = Rectangle(p1, p2)
        self.rectangle.setWidth(2)
        self.rectangle.setFill('#9cd37c')
        self.rectangle.setOutline('#1b7709')
        self.rectangle.draw(win)
        self.label = Text(self.rectangle.getCenter(), label)
        self.label.setFill('#1b7709')
        self.label.setFace('courier')
        self.label.setStyle('bold')
        self.label.draw(win)
        self.type = "action"
        self.fun = fun
        self.args = args
        self.drawn = False

    def action(self):
        if self.args:
            return self.fun(*self.args)
        else:
            return self.fun()

    def undraw(self):
        self.rectangle.undraw()
        self.label.undraw()

    def draw(self):
        self.rectangle.draw(self.win)
        self.label.draw(self.win)


class Menu():
    def __init__(self, win,buttons, windows):  # windows is a list with the different objects in that window
        self.win = win
        self.buttons = buttons
        self.windows = windows
        self.currentWindow = 0
        self.buttons[0].changeState()
        self.drawWindow()

    def drawWindow(self):
        for object in self.windows[self.currentWindow]:
            if type(object) in [OptionButton,Switch,ActionButton,SwitchMultiple]:
                if not object.drawn:
                    object.draw()
                    object.drawn = True
            else:
                object.draw(self.win)
                object.drawn = True

    def undrawWindow(self):
        for object in self.windows[self.currentWindow]:
            if type(object) in [OptionButton,Switch,ActionButton,SwitchMultiple]:
                    object.drawn = False
            object.undraw()


    def changeWindow(self, button):
        clicked = self.buttons.index(button)
        if self.currentWindow != clicked:
            self.buttons[self.currentWindow].changeState()
            self.undrawWindow()
            self.currentWindow = clicked
            self.buttons[self.currentWindow].changeState()
            self.drawWindow()

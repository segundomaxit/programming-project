from tools import *


def mainWindow():
    w, h = 1400, 750  # Width and height.
    x, y = 65, 30  # Screen position.
    win = GraphWin("Main", w, h)
    win.setBackground('white')
    win.master.geometry('%dx%d+%d+%d' % (w, h, x, y))
    win.setCoords(0, 0, 280, 150)
    top = Rectangle(Point(0, 150), Point(280, 120))
    top.setFill('#1b7709')
    top.setOutline('#1b7709')
    title = Text(Point(30, 140), 'ENERGi.CO')
    title.setSize(36)
    title.setFace("courier")
    title.setFill('#cbf3ae')
    title.setStyle("bold")
    config = Text(Point(240, 115), "Configurations")
    config.setSize(25)
    config.setFill("#1b7709")
    config.setFace("courier")
    config.setStyle("bold")
    panel = Rectangle(Point(200, 120), Point(280, 0))
    panel.setFill('#cbf3ae')
    panel.setOutline('#cbf3ae')
    panel.draw(win)
    top.draw(win)
    title.draw(win)
    config.draw(win)

    return win

def MenuButtons(win):
    tsButton = OptionButton(win,Point(0,130),Point(60,120),"Time Series",widthOn=0,widthOff=0,fill='#1b7709',fillOn='white',fillOff='#82c268',bold=True,size=16,type='menu')
    cButton = OptionButton(win,Point(70,130),Point(130,120),"Bar Graphs",widthOn=0,widthOff=0,fill='#1b7709',fillOn='white',fillOff='#82c268',bold=True,size=16,type='menu')
    fButton = OptionButton(win,Point(130,130),Point(200,120),"Forecasting",widthOn=0,widthOff=0,fill='#1b7709',fillOn='white',fillOff='#82c268',bold=True,size=16,type='menu')

    return [tsButton,cButton,fButton]


def TimeSeries(win):
    date1 = Text(Point(220, 100), "Initial:")
    date1.setSize(12)
    date1.setFill("#1b7709")
    date1.setFace("courier")

    date2 = date1.clone()
    date2.setText("Final:")
    date2.move(35, 0)

    date3 = date1.clone()
    date3.setText("Date Range (dd/mm/yyyy):")
    date3.setSize(13)
    date3.setStyle("bold")
    date3.move(10, 5)

    dateInitial = Entry(Point(222, 95), 10)
    dateInitial.setText('01/11/2010')
    dateInitial.setFace('courier')
    dateInitial.setFill('white')

    dateFinal = dateInitial.clone()
    dateFinal.setText('26/11/2010')
    dateFinal.setFace('courier')
    dateFinal.move(35, 0)

    periodText = date3.clone()
    periodText.setText('Time Between Observations:')
    periodText.move(2,-17)

    hour = OptionButton(win, Point(217.5, 83), Point(232.5, 76), '1 Hour', bold=True,type='switchMultiple')
    day = OptionButton(win, Point(232.5, 83), Point(247.5, 76), '1 Day', bold=True,type='switchMultiple')
    month = OptionButton(win, Point(247.5, 83), Point(262.5, 76), '1 Month', bold=True,type='switchMultiple')

    period = SwitchMultiple([hour,day,month])

    display = date3.clone()
    display.setText("Display:")
    display.move(-14, -34)

    homeLocation = display.clone()
    homeLocation.setText("Home Location:")
    homeLocation.move(6, -20)

    kitchen = OptionButton(win, Point(202.5, 45), Point(217.5, 38), 'Kitchen', bold=True)
    laundry = OptionButton(win, Point(217.5, 45), Point(232.5, 38), 'Laundry', bold=True)
    heating = OptionButton(win, Point(232.5, 45), Point(247.5, 38), 'Heating', bold=True)
    other = OptionButton(win, Point(247.5, 45), Point(262.5, 38), 'Other', bold=True)
    total = OptionButton(win, Point(262.5, 45), Point(277.5, 38), 'All', bold=True)

    displaySwitch = Switch(OptionButton(win, Point(215, 65), Point(240, 58), 'Consumption', bold=True),
                                 OptionButton(win, Point(240, 65), Point(265, 58), "Cost", bold=True))

    title = homeLocation.clone()
    title.setText("Title:")
    title.move(-7, -18)

    titleText = Entry(Point(240, 25), 25)
    titleText.setSize(15)
    titleText.setText("Time Series Plot")
    titleText.setFace('courier')
    titleText.setFill('white')

    return {'Date':[dateInitial,dateFinal],
            'Period':period,
            'Display':displaySwitch,
            'Location':[kitchen,laundry,heating,other,total],
            'Title':titleText,
            'Other':[date1, date2, date3,display,homeLocation,title,periodText]}




def Cumulative(win):
    date1 = Text(Point(220, 100), "Initial:")
    date1.setSize(12)
    date1.setFill("#1b7709")
    date1.setFace("courier")

    date2 = date1.clone()
    date2.setText("Final:")
    date2.move(35, 0)

    date3 = date1.clone()
    date3.setText("Date Range (dd/mm/yyyy):")
    date3.setSize(13)
    date3.setStyle("bold")
    date3.move(10, 5)

    dateInitial = Entry(Point(222, 95), 10)
    dateInitial.setText('01/01/2007')
    dateInitial.setFace('courier')
    dateInitial.setFill('white')

    dateFinal = dateInitial.clone()
    dateFinal.setText('26/11/2010')
    dateFinal.setFace('courier')
    dateFinal.move(35, 0)

    periodText = date3.clone()
    periodText.setText('Plot Mean Consumption per:')
    periodText.move(4,-17)

    hour = OptionButton(win, Point(202.5, 83), Point(227.5, 76), 'Hour of Day', bold=True,type='switchMultiple')
    day = OptionButton(win, Point(227.5, 83), Point(252.5, 76), 'Weekday', bold=True,type='switchMultiple')
    month = OptionButton(win, Point(252.5, 83), Point(277.5, 76), 'Month', bold=True,type='switchMultiple')

    period = SwitchMultiple([hour,day,month])

    display = date3.clone()
    display.setText("Display:")
    display.move(-14, -34)

    homeLocation = display.clone()
    homeLocation.setText("Home Location:")
    homeLocation.move(6, -20)

    kitchen = OptionButton(win, Point(210, 45), Point(225, 38), 'Kitchen', bold=True)
    laundry = OptionButton(win, Point(225, 45), Point(240, 38), 'Laundry', bold=True)
    heating = OptionButton(win, Point(240, 45), Point(255, 38), 'Heating', bold=True)
    other = OptionButton(win, Point(255, 45), Point(270, 38), 'Other', bold=True)

    displaySwitch = Switch(OptionButton(win, Point(215, 65), Point(240, 58), 'Consumption', bold=True),
                                 OptionButton(win, Point(240, 65), Point(265, 58), "Cost", bold=True))

    title = homeLocation.clone()
    title.setText("Title:")
    title.move(-7, -18)

    titleText = Entry(Point(240, 25), 25)
    titleText.setSize(15)
    titleText.setText("Mean Consumption Bar Plot")
    titleText.setFace('courier')
    titleText.setFill('white')

    return {'Date':[dateInitial,dateFinal],
            'Period':period,
            'Display':displaySwitch,
            'Location':[kitchen,laundry,heating,other],
            'Title':titleText,
            'Other':[date1, date2, date3,display,homeLocation,title,periodText]}



def Forecasting(win):

    forecastTitle = Text(Point(231, 100),"Forecasting Period:")
    forecastTitle.setSize(14)
    forecastTitle.setStyle("bold")
    forecastTitle.setFace('courier')
    forecastTitle.setFill("#1b7709")

    day = OptionButton(win, Point(210, 95), Point(225, 88), '1 Day', bold=True,type='switchMultiple')
    week = OptionButton(win, Point(225, 95), Point(240, 88), '1 Week', bold=True,type='switchMultiple')
    month = OptionButton(win, Point(240, 95), Point(255, 88), '1 Month', bold=True,type='switchMultiple')
    year = OptionButton(win, Point(255, 95), Point(270, 88), '1 Year', bold=True,type='switchMultiple')

    forecastPeriod = SwitchMultiple([day,week,month,year])


    locationTitle = Text(Point(226, 50),"Home Location:")
    locationTitle.setSize(14)
    locationTitle.setStyle("bold")
    locationTitle.setFace('courier')
    locationTitle.setFill("#1b7709")
    kitchen = OptionButton(win, Point(202.5, 45), Point(217.5, 38), 'Kitchen', bold=True,type='switchMultiple')
    laundry = OptionButton(win, Point(217.5, 45), Point(232.5, 38), 'Laundry', bold=True,type='switchMultiple')
    heating = OptionButton(win, Point(232.5, 45), Point(247.5, 38), 'Heating', bold=True,type='switchMultiple')
    other = OptionButton(win, Point(247.5, 45), Point(262.5, 38), 'Other', bold=True,type='switchMultiple')
    total = OptionButton(win, Point(262.5, 45), Point(277.5, 38), 'All', bold=True,type='switchMultiple')
    location = SwitchMultiple([kitchen, laundry, heating, other, total])

    display = Text(Point(220, 75),"Display:")
    display.setSize(14)
    display.setStyle("bold")
    display.setFace('courier')
    display.setFill("#1b7709")
    displaySwitch = Switch(OptionButton(win, Point(215, 70), Point(240, 60), 'Consumption', bold=True),
                                 OptionButton(win, Point(240, 70), Point(265, 60), "Cost", bold=True))


    return {'Period': forecastPeriod,
            'Display':displaySwitch,
            'Location':location,
            'Other':[forecastTitle,display,locationTitle]}





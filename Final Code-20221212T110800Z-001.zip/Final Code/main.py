from windows import *
from functions import *


def main():
    win = mainWindow()

    timeSeriesDic = TimeSeries(win)
    timeSeriesList = Dic2List(timeSeriesDic)

    cumulativeDic = Cumulative(win)
    cumulativeList = Dic2List(cumulativeDic)

    forecastingDic = Forecasting(win)
    forecastingList = Dic2List(forecastingDic)

    menuWindows = [timeSeriesList, cumulativeList, forecastingList]
    menuDic = [timeSeriesDic, cumulativeDic, forecastingDic]
    menuButtons = MenuButtons(win)

    for menuButton in menuButtons:
        menuButton.draw()

    quitButton = ActionButton(win, Point(272, 150), Point(280, 147), "Quit", win.close)
    plotButton = ActionButton(win, Point(227, 19), Point(253, 11), "Create Plot", createPlot,
                              args=[win, menuButtons, menuWindows, menuDic])

    switches = [object for object in timeSeriesList + cumulativeList + forecastingList if
                type(object) is SwitchMultiple]

    buttons = menuButtons + \
              [plotButton,quitButton] + \
              [object for object in timeSeriesList + cumulativeList + forecastingList if
               type(object) in [OptionButton, Switch, ActionButton]] + \
              [button for switch in switches for button in switch.buttons]

    menu = Menu(win, menuButtons, menuWindows)

    checkClicks(win, buttons, menu, switches)


main()
